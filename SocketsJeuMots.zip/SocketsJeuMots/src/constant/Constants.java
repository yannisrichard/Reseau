/**
 * 
 */
package constant;

/**
 * @author Yannis
 * La classe Constants.
 */
public final class Constants {
		
	/** Adresse du serveur. */
	public static final String ADDR_SERVER = "localhost";
	
}
