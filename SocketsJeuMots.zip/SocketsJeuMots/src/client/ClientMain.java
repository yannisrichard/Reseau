/**
 * 
 */
package client;

/**
 * @author yarichard1
 *
 */
public class ClientMain {

	/**
	 * Le main.
	 * @param args Les arguments.
	 */
	public static void main(String[] args)
	{
		new Client(16000, 15000, "localhost");
	}
}
