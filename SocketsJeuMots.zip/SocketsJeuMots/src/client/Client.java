/**
 * 
 */
package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;

import constant.Constants;

/**
 * @author yarichard1
 *
 */
public class Client {

	private int port;
	
	public Client(int port, String adresse){
		this.port = port;
		String ligne, result;
		PrintStream out = null;
		
		try {
			Socket sock = new Socket(adresse, this.port);
			BufferedReader clavier = new BufferedReader(new InputStreamReader(System.in));
			
			out = new PrintStream(sock.getOutputStream());
		    BufferedReader clavierSoc = new BufferedReader(new InputStreamReader(sock.getInputStream()));
		    
		    System.out.println(clavierSoc.readLine());
	        System.out.println("*********** En attente d'une opération **************");
		    System.out.println("Commande -> Voyelle, Consonne, Caractere, Valeur, Fin");
		    System.out.println("Exemple  -> Voyelle : votre texte");
		    System.out.println("\nCommande : ");
	        
			ligne = clavier.readLine();
		    while (!ligne.equals("Fin")) {
				String[] splitLine = ligne.split(":");
		    	if(splitLine[0].equals("Voyelle ") || splitLine[0].equals("Consonne ")){
		        	out.println(ligne);
			    	result = clavierSoc.readLine();
			    	System.out.println(result);
			    	System.out.println("Autre operation : ");
		    	} 
		    	else {
		    		if (ligne.contains("Caractere ")) {
		    			caractere(ligne);
		    		}
		    		else {
		    			if (ligne.contains("Valeur ")) {
		    				valeur(ligne);
		    			}
			    	}
		    	}
		        ligne = clavier.readLine();	

			}
	        System.out.println("------------- Fin --------------");
		    out.println("fin");
		    clavierSoc.close();
		    out.close();
		    clavier.close();
	    	sock.close();
			
		}
	    catch (IOException e){
			System.out.println("Erreur de connexion avec le serveur.");
		}
	}
	
	/**
	 * Methode qui calcule le nombre de caractere en appelant le serveur web.
	 * @param ligne La ligne ecrite par l'user
	 */
	private void caractere(String ligne) 
	{
		String[] splitLine = ligne.split("Caractere :");
		if (2 == splitLine.length) {
			String result = httpGet(splitLine[1]);
			if (null != result) {
				System.out.println(result);
			}
        }
        else {
        	System.out.println("Operation inconnue.");
        }
    	System.out.println("Autre operation : ");
	}
	
	/**
	 * Methode qui donne la valeur d'une phrase en appelant le serveur web.
	 * @param ligne La ligne ecrite par l'user
	 */
	private void valeur(String ligne) 
	{
		String[] splitLine = ligne.split("Valeur :");
		if (2 == splitLine.length) {
			String result = httpPost(splitLine[1]);
			if (null != result) {
				System.out.println(result);
			}
        }
        else {
        	System.out.println("Operation inconnue.");
        }
    	System.out.println("Autre operation : ");
	}

	private String httpGet(String phrase)
	{
		try {
			@SuppressWarnings("resource")
			Socket socweb = new Socket(Constants.ADDR_SERVER, 80);
			BufferedReader keyboard = new BufferedReader(new InputStreamReader(socweb.getInputStream()));
			PrintStream out = new PrintStream(socweb.getOutputStream());
			StringBuilder builder = new StringBuilder();
			// Dossier du projet web
			String folder = "/ServerPhp/";
			builder.append("GET ").append(folder).append("index.php?phrase=").append(phrase).append("&lastNumber=")
				   .append(" HTTP/1.1\r\nHost:").append(Constants.ADDR_SERVER).append("\r\n\r\n");
			out.println(builder.toString());
			String value = "";
			int count = 0;
	        while ((value = keyboard.readLine()) != null) {
	        	if (7 == count) {
	        		return value;
	        	}
	        	count ++;
	        }
		} 
		catch (UnknownHostException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private String httpPost(String phrase)
	{
		try {
			@SuppressWarnings("resource")
			Socket socweb = new Socket(Constants.ADDR_SERVER, 80);
			BufferedReader keyboard = new BufferedReader(new InputStreamReader(socweb.getInputStream()));
			PrintStream out = new PrintStream(socweb.getOutputStream());
			StringBuilder builder = new StringBuilder();
			// Dossier du projet web
			String folder = "/ServerPhp/";
			builder.append("POST ").append(folder).append("calculate.php HTTP/1.1\r\nHost:").append(Constants.ADDR_SERVER).append("\r\n")
					.append("Content-type: application/x-www-form-urlencoded\r\nContent-Length: 33\r\n\r\nfphrase=")
				   .append(phrase);
			out.println(builder.toString());
			String value = "";
			int count = 0;
	        while ((value = keyboard.readLine()) != null) {
	        	if (16 == count) {
	        		return value;
	        	}
	        	count++;
	        }
		} 
		catch (UnknownHostException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	
	
	
	

}
